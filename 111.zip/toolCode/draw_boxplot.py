# 导入数据处理库pandas
import pandas as pd
# 导入数据可视化库matplotlib
import matplotlib.pyplot as plt
# 设置随机种子，以便结果可重现
import numpy as np
np.random.seed(0)

# 生成模拟数据
data = {
    'A': np.random.normal(0, 1, 100),
    'B': np.random.normal(1, 2, 100),
    'C': np.random.normal(2, 1, 100),
    'D': np.random.normal(3, 1.5, 100)
}

# 将数据转换为DataFrame格式
df = pd.DataFrame(data)
# 创建箱线图
plt.figure(figsize=(10, 6))
plt.boxplot([df['A'], df['B'], df['C'], df['D']], labels=['A', 'B', 'C', 'D'])
plt.title('箱线图示例')
plt.ylabel('数值')
plt.grid(axis='y')  # 添加y轴网格
# 显示箱线图
plt.show()

# 保存图形为PNG文件
# plt.savefig('boxplot_example.png', format='png', bbox_inches='tight')